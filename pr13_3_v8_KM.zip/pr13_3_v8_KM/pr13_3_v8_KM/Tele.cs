﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr13_3_v8_KM
{
    class Tele
    {
        private string firm;
        private string model;
        private string sell;
        private string memory;
        private string battery;
        private string day;
        private string address;

        public Tele(string firm, string model, int sell, int mem, string batt, string day, string address)
        {
            this.firm = firm;
            this.model = model;
            this.sell = sell.ToString() + " руб";
            this.memory = mem.ToString() + " ГБ";
            this.battery = batt;
            this.day = day;
            this.address = address;
        }
        public string getFirm()
        {
            return this.firm;
        }
        public string getModel()
        {
            return this.model;
        }
        public string getSell()
        {
            return this.sell.ToString();
        }
        public string getMem()
        {
            return this.memory.ToString();
        }
        public string getBatt()
        {
            return this.battery;
        }
        public string getDay()
        {
            return this.day;
        }
        public string getAddress()
        {
            return this.address;
        }
        public void setName(string firm)
        {
            this.firm = firm;
        }
        public void setModel(string model)
        {
            this.model = model;
        }
        public void setSell(int sell)
        {
            this.sell = sell.ToString();
        }
        public void setMem(int mem)
        {
            this.memory = mem.ToString();
        }
        public void setMail(string batt)
        {
            this.battery = batt;
        }
        public void setBirth(string day)
        {
            this.day = day;
        }
        public void setAddress(string address)
        {
            this.address = address;
        }
    }
}
