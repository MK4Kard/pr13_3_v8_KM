﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Xml.Linq;

namespace pr13_3_v8_KM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            initDataGridView();
        }

        Tele c;

        private DataGridViewColumn dataGridViewColumn1 = null;
        private DataGridViewColumn dataGridViewColumn2 = null;
        private DataGridViewColumn dataGridViewColumn3 = null;
        private DataGridViewColumn dataGridViewColumn4 = null;
        private DataGridViewColumn dataGridViewColumn5 = null;
        private DataGridViewColumn dataGridViewColumn6 = null;
        private DataGridViewColumn dataGridViewColumn7 = null;

        private void initDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Add(getDataGridViewColumn1());
            dataGridView1.Columns.Add(getDataGridViewColumn2());
            dataGridView1.Columns.Add(getDataGridViewColumn3());
            dataGridView1.Columns.Add(getDataGridViewColumn4());
            dataGridView1.Columns.Add(getDataGridViewColumn5());
            dataGridView1.Columns.Add(getDataGridViewColumn6());
            dataGridView1.Columns.Add(getDataGridViewColumn7());
            dataGridView1.AutoResizeColumns();
        }
        private DataGridViewColumn getDataGridViewColumn1()
        {
            if (dataGridViewColumn1 == null)
            {
                dataGridViewColumn1 = new DataGridViewTextBoxColumn();
                dataGridViewColumn1.Name = "";
                dataGridViewColumn1.HeaderText = "Фирма";
                dataGridViewColumn1.ValueType = typeof(string);
                dataGridViewColumn1.Width = dataGridView1.Width / 7;
            }
            return dataGridViewColumn1;
        }
        private DataGridViewColumn getDataGridViewColumn2()
        {
            if (dataGridViewColumn2 == null)
            {
                dataGridViewColumn2 = new DataGridViewTextBoxColumn();
                dataGridViewColumn2.Name = "";
                dataGridViewColumn2.HeaderText = "Модель";
                dataGridViewColumn2.ValueType = typeof(string);
                dataGridViewColumn2.Width = dataGridView1.Width / 7;
            }
            return dataGridViewColumn2;
        }
        private DataGridViewColumn getDataGridViewColumn3()
        {
            if (dataGridViewColumn3 == null)
            {
                dataGridViewColumn3 = new DataGridViewTextBoxColumn();
                dataGridViewColumn3.Name = "";
                dataGridViewColumn3.HeaderText = "Цена";
                dataGridViewColumn3.ValueType = typeof(string);
                dataGridViewColumn3.Width = dataGridView1.Width / 7;
            }
            return dataGridViewColumn3;
        }
        private DataGridViewColumn getDataGridViewColumn4()
        {
            if (dataGridViewColumn4 == null)
            {
                dataGridViewColumn4 = new DataGridViewTextBoxColumn();
                dataGridViewColumn4.Name = "";
                dataGridViewColumn4.HeaderText = "Количество памяти";
                dataGridViewColumn4.ValueType = typeof(string);
                dataGridViewColumn4.Width = dataGridView1.Width / 7;
            }
            return dataGridViewColumn4;
        }
        private DataGridViewColumn getDataGridViewColumn5()
        {
            if (dataGridViewColumn5 == null)
            {
                dataGridViewColumn5 = new DataGridViewTextBoxColumn();
                dataGridViewColumn5.Name = "";
                dataGridViewColumn5.HeaderText = "Продолжительность заряда";
                dataGridViewColumn5.ValueType = typeof(string);
                dataGridViewColumn5.Width = dataGridView1.Width / 7;
            }
            return dataGridViewColumn5;
        }
        private DataGridViewColumn getDataGridViewColumn6()
        {
            if (dataGridViewColumn6 == null)
            {
                dataGridViewColumn6 = new DataGridViewTextBoxColumn();
                dataGridViewColumn6.Name = "";
                dataGridViewColumn6.HeaderText = "Дата выпуска";
                dataGridViewColumn6.ValueType = typeof(string);
                dataGridViewColumn6.Width = dataGridView1.Width / 7;
            }
            return dataGridViewColumn6;
        }
        private DataGridViewColumn getDataGridViewColumn7()
        {
            if (dataGridViewColumn7 == null)
            {
                dataGridViewColumn7 = new DataGridViewTextBoxColumn();
                dataGridViewColumn7.Name = "";
                dataGridViewColumn7.HeaderText = "Адрес доставки";
                dataGridViewColumn7.ValueType = typeof(string);
                dataGridViewColumn7.Width = dataGridView1.Width / 7;
            }
            return dataGridViewColumn7;
        }

        private HashSet<Tele> tel = new HashSet<Tele>();

        private void addTele(string firm, string model, int sell, int memory, string battery, string day, string address)
        {
            if (firm == string.Empty || model == string.Empty || sell == null || memory == null || battery == string.Empty || address == string.Empty)
            {
                MessageBox.Show("Заполните все поля");
            }
            else
            {
                if (tel.Any(s => s.getFirm() == firm && s.getModel() == model && s.getMem() == memory.ToString() && s.getBatt() == battery && s.getDay() == day && s.getAddress() == address))
                {
                    MessageBox.Show("Телефон с такими данными уже есть", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    var contact = new Tele(firm, model, sell, memory, battery, day, address);
                    tel.Add(contact);
                }
            }
            showListInGrid();
        }
        private void deleteTele(int index)
        {
            List<Tele> contactList = new List<Tele>(tel);
            Tele contactToRemove = contactList[index];
            tel.Remove(contactToRemove);
            showListInGrid();
        }
        private void showListInGrid()
        {
            dataGridView1.Rows.Clear();

            foreach (Tele s in tel)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell cell1 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell4 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell5 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell6 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell7 = new
                DataGridViewTextBoxCell();
                cell1.ValueType = typeof(string);
                cell1.Value = s.getFirm();
                cell2.ValueType = typeof(string);
                cell2.Value = s.getModel();
                cell3.ValueType = typeof(string);
                cell3.Value = s.getSell();
                cell4.ValueType = typeof(string);
                cell4.Value = s.getMem();
                cell5.ValueType = typeof(string);
                cell5.Value = s.getBatt();
                cell6.ValueType = typeof(string);
                cell6.Value = s.getDay();
                cell7.ValueType = typeof(string);
                cell7.Value = s.getAddress();
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                row.Cells.Add(cell4);
                row.Cells.Add(cell5);
                row.Cells.Add(cell6);
                row.Cells.Add(cell7);
                dataGridView1.Rows.Add(row);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1 != null || textBox2 != null || numericUpDown1 != null || numericUpDown2 != null || textBox5 != null || textBox6 != null)
                {
                    addTele(textBox1.Text, textBox2.Text, Convert.ToInt32(numericUpDown1.Value), Convert.ToInt32(numericUpDown2.Value), textBox5.Text, dateTimePicker1.Text, textBox6.Text);
                }
            }
            catch
            {

            }
        }

        private void splitContainer1_Panel2_Paint(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedRow = dataGridView1.SelectedCells[0].RowIndex;
            DialogResult dr = MessageBox.Show("Удалить информацию про телефон?", "", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    deleteTele(selectedRow);
                }
                catch (Exception)
                {

                }
            }
        }
    }
}
