﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr13_3_v8_KM
{
    class Tel
    {
    }
}
